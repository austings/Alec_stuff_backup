#include <stdint.h>

#define INT_MIN INT32_MIN
#define INT_MAX INT32_MAX
#define LONG_MIN INT32_MIN
#define LONG_MAX INT32_MAX
#define LLONG_MIN INT64_MIN
#define LLONG_MAX INT64_MAX

