void time_busy(i64 duration);
i64 time_jiffies();
i64 time_now();
void time_sleep(i64 duration);