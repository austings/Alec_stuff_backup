## erythros

A comfy desktop environment for TempleOS


![Screenshot_2025-05-09_14-25-31](https://git.checksum.fail/alec/erythros/raw/branch/master/screenshot.png)
