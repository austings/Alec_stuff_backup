u8 ioport_read_u8(u16 address);
u16 ioport_read_u16(u16 address);
u32 ioport_read_u32(u16 address);
void ioport_write_u8(u16 address, u8 value);
void ioport_write_u16(u16 address, u16 value);
void ioport_write_u32(u16 address, u32 value);
