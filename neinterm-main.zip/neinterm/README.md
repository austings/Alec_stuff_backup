# neinterm

drawterm-like client for TempleOS; to connect to Plan 9 CPU servers