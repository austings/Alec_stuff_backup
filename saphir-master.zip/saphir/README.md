# saphir

Tiling window extensions for TempleOS WinMgr

![saphir](https://git.checksum.fail/alec/saphir/raw/branch/master/screenshot.png? "saphir")

# Info

Saphir extends the existing TempleOS WinMgr to provide tiling window functionality, as well as provide some sane defaults to those who prefer a less "blinky" interface.

The active window is displayed with `LTRED` border color; inactive windows use `LTGRAY` border color.

Cursors are automatically hidden for inactive windows; the active window cursor blinks `CYAN` & `WHITE` instead of `YELLOW` and `BLACK`.

The current `CTask` address and `task_title` is displayed on a status bar at the bottom of the screen.

Saphir does not require you to recompile your Kernel; any changes to existing functions are live-patched and not persistent.

# Usage

`#include "Run";`

# Keyboard shortcuts

`ALT` + arrow keys : navigate windows

`ALT` + `h` : split window horizontal

`ALT` + `v` : split window vertical

