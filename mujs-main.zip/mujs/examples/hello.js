print("Hello, TempleOS, from MuJS!")
print("Current date and time is: " + new Date().toString());
print("Type mujs; for a REPL, or mujs(\"path/to/file.js\"); to run a program.");
