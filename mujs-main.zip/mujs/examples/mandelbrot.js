/**
 *  autor: foqc
 *  github: foqc
 */
// noprotect

function mandelbrot(c) {
    var MAX_ITERATION = 80
    var z = { x: 0, y: 0 }, n = 0, p, d
    do {
        p = {
            x: Math.pow(z.x, 2) - Math.pow(z.y, 2),
            y: 2 * z.x * z.y
        }
        z = {
            x: p.x + c.x,
            y: p.y + c.y
        }
        d = Math.sqrt(Math.pow(z.x, 2) + Math.pow(z.y, 2))
        n += 1
    } while (d <= 2 && n < MAX_ITERATION)
    isMandelbrotSet = d <= 2
    return n
}

function draw() {
    var ctx = DC.alias()
    var isMandelbrotSet = false
    var colors = []
    for (var i = 0; i < 16; i++)
        colors[i] = i === 0 ? 0 : Math.random() * 16

    var WIDTH = 320
    var HEIGHT = 240

    var REAL_SET = { start: -2, end: 1 }
    var IMAGINARY_SET = { start: -1, end: 1 }

    var ox = 640 - WIDTH - 8
    var oy = 480 - HEIGHT - 8
    for (var i = 0; i < WIDTH; i++) {
        for (var j = 0; j < HEIGHT; j++) {
            complex = {
                x: REAL_SET.start + (i / WIDTH) * (REAL_SET.end - REAL_SET.start),
                y: IMAGINARY_SET.start + (j / HEIGHT) * (IMAGINARY_SET.end - IMAGINARY_SET.start)
            }

            m = mandelbrot(complex)

            DC.set_color(ctx, colors[isMandelbrotSet ? 0 : (m % colors.length - 1) + 1])
            Gr.plot(ctx, ox + i, oy + j)
            OS.sleep(0)
        }
    }
}

draw()

print("Hello, TempleOS, from MuJS!")
alert("This is an alert!")
