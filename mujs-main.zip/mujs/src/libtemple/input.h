uint64_t input_key_down(uint64_t sc);
