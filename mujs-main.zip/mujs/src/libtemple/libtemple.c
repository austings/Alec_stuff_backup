unsigned long input_key_down(unsigned long sc) { return 0; }

unsigned long os_call_ext_str(char const* func) { return 0; }

unsigned long os_call_ext_str_1(char const* func, unsigned long arg1) { return 0; }

unsigned long os_call_ext_str_2(char const* func, unsigned long arg1, unsigned long arg2) { return 0; }

unsigned long os_call_ext_str_3(char const* func, unsigned long arg1, unsigned long arg2, unsigned long arg3) { return 0; }

unsigned long os_call_ext_str_4(char const* func, unsigned long arg1, unsigned long arg2, unsigned long arg3, unsigned long arg4) { return 0; }

unsigned long os_call_ext_str_5(char const* func, unsigned long arg1, unsigned long arg2, unsigned long arg3, unsigned long arg4, unsigned long arg5) { return 0; }

unsigned long os_jiffies() { return 0; }
