uint64_t os_call_ext_str(char const* func);
uint64_t os_call_ext_str_1(char const* func, uint64_t arg1);
uint64_t os_call_ext_str_2(char const* func, uint64_t arg1, uint64_t arg2);
uint64_t os_call_ext_str_3(char const* func, uint64_t arg1, uint64_t arg2, uint64_t arg3);
uint64_t os_call_ext_str_4(char const* func, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4);
uint64_t os_call_ext_str_5(char const* func, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5);
unsigned long os_jiffies();
