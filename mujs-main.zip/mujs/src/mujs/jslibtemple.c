#include <stdbool.h>
#include <inttypes.h>

#include "../libtemple/input.h"
#include "../libtemple/os.h"

#define value_or_number(v, x) js_isundefined(J, x) ? v : js_tonumber(J, x)
#define null_or_number(x) value_or_number(0, x)

/** DC **/

// public CDC *DCAlias(CDC *dc=NULL,CTask *task=NULL)
void DC_alias(js_State *J)
{
    long dc = null_or_number(1);
    long task = null_or_number(2);
    js_pushnumber(J, os_call_ext_str_2("DCAlias", dc, task));
}

// public U0 DCClear(CDC *dc=NULL)
void DC_clear(js_State *J)
{
    long dc = null_or_number(1);
    os_call_ext_str_1("DCClear", dc);
    js_pushundefined(J);
}

// public CDC *DCCopy(CDC *dc,CTask *task=NULL)
void DC_copy(js_State *J)
{
    long dc = null_or_number(1);
    long task = null_or_number(2);
    js_pushnumber(J, os_call_ext_str_2("DCCopy", dc, task));
}

// public U0 DCDel(CDC *dc)
void DC_delete(js_State *J)
{
    if (!js_isundefined(J, 1)) {
        os_call_ext_str_1("DCDel", js_tonumber(J, 1));
    }
    js_pushundefined(J);
}

// public U0 DCFill(CDC *dc=NULL,CColorROPU32 val=TRANSPARENT)
void DC_fill(js_State *J)
{
    long dc = null_or_number(1);
    long color = value_or_number(255, 2);
    os_call_ext_str_2("DCFill", dc, color);
    js_pushundefined(J);
}

// public CDC *DCNew(I64 width,I64 height,CTask *task=NULL,Bool null_bitmap=FALSE)
void DC_new(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2)) {
        js_pushundefined(J);
        return;
    }
    long width = js_tonumber(J, 1);
    long height = js_tonumber(J, 2);
    long task = null_or_number(3);
    long null_bitmap = null_or_number(4);
    js_pushnumber(J, os_call_ext_str_4("DCNew", width, height, task, null_bitmap));
}

// public I64 DCColorChg(CDC *dc,I64 src_color,I64 dst_color=TRANSPARENT)
void DC_replace_color(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2)) {
        js_pushundefined(J);
        return;
    }
    long dc = js_tonumber(J, 1);
    long src_color = js_tonumber(J, 2);
    long dst_color = value_or_number(255, 3);
    js_pushnumber(J, os_call_ext_str_3("DCColorChg", dc, src_color, dst_color));
}

// DC.set_color(dc, color)
void DC_set_color(js_State *J)
{
    if (!js_isundefined(J, 1) && !js_isundefined(J, 2)) {
        long dc = js_tonumber(J, 1);
        long color = js_tonumber(J, 2);
        memset((void*)(dc + 0xa0), color, 1); // offset(CDC.color) == 0xa0
    }
    js_pushundefined(J);
}

void jsLT_initdc(js_State *J)
{
    js_pushobject(J, jsV_newobject(J, -1, J->Object_prototype));
    {
        jsB_propf(J, "DC.alias", DC_alias, 1);
        jsB_propf(J, "DC.clear", DC_clear, 1);
        jsB_propf(J, "DC.copy", DC_copy, 4);
        jsB_propf(J, "DC.delete", DC_delete, 1);
        jsB_propf(J, "DC.fill", DC_fill, 2);
        jsB_propf(J, "DC.new", DC_new, 2);
        jsB_propf(J, "DC.replace_color", DC_replace_color, 3);
        jsB_propf(J, "DC.set_color", DC_set_color, 2);
    }
    js_defglobal(J, "DC", JS_DONTENUM);
}

/** Gr **/

// public I64 GrBlot(CDC *dc=gr.dc,I64 x,I64 y,CDC *img)
void Gr_blot(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2) || js_isundefined(J, 3) || js_isundefined(J, 4)) {
        js_pushundefined(J);
        return;
    }
    long dc = js_tonumber(J, 1);
    long x = js_tonumber(J, 2);
    long y = js_tonumber(J, 3);
    long img = js_tonumber(J, 4);
    js_pushnumber(J, os_call_ext_str_4("GrBlot", dc, x, y, img));
}

// public I64 GrPeek(CDC *dc=gr.dc,I64 x,I64 y)
void Gr_peek(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2) || js_isundefined(J, 3)) {
        js_pushundefined(J);
        return;
    }
    long dc = js_tonumber(J, 1);
    long x = js_tonumber(J, 2);
    long y = js_tonumber(J, 3);
    js_pushnumber(J, os_call_ext_str_3("GrPeek", dc, x, y));
}

// public Bool GrPlot(CDC *dc=gr.dc,I64 x,I64 y)
void Gr_plot(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2) || js_isundefined(J, 3)) {
        js_pushundefined(J);
        return;
    }
    long dc = js_tonumber(J, 1);
    long x = js_tonumber(J, 2);
    long y = js_tonumber(J, 3);
    js_pushboolean(J, os_call_ext_str_3("GrPlot", dc, x, y));
}

void jsLT_initgr(js_State *J)
{
    js_pushobject(J, jsV_newobject(J, -1, J->Object_prototype));
    {
        jsB_propf(J, "Gr.blot", Gr_blot, 4);
        jsB_propf(J, "Gr.peek", Gr_peek, 3);
        jsB_propf(J, "Gr.plot", Gr_plot, 3);
    }
    js_defglobal(J, "Gr", JS_DONTENUM);
}

/** Input **/

uint64_t get_glbl_var_addr(char* name)
{
    // 0x100300 + 0x3d0: adam_task + offset(CTask.hash_table)
    // 0x8: HTT_GLBL_VAR
    // 0x78: offset(CHashGlblVar.data_addr)
    uint64_t addr = os_call_ext_str_4("HashFind", (uint64_t)name, *(uint64_t*)(0x100300 + 0x3d0), 8, 1);
    return addr ? *(uint64_t*)(addr + 0x78) : 0;
}

void Input_get_char(js_State *J)
{
    js_pushnumber(J, os_call_ext_str_3("GetChar", 0, 0, 0));
}

void Input_get_string(js_State *J)
{
    char* res = (char*)os_call_ext_str_3("GetStr", js_isundefined(J, 1) ? 0 : (uint64_t)js_tostring(J, 1), 0, 0);
    if (!res) {
        js_pushundefined(J);
        return;
    }
    js_pushstring(J, res);
    free(res);
}

void Input_mouse_x(js_State *J)
{
    uint64_t* res = (uint64_t*)get_glbl_var_addr("ms");
    js_pushnumber(J, res[0]); // offset(CMsStateGlbls.pos.x)
}

void Input_mouse_y(js_State *J)
{
    uint64_t* res = (uint64_t*)get_glbl_var_addr("ms");
    js_pushnumber(J, res[1]); // offset(CMsStateGlbls.pos.y)
}

void Input_mouse_lb(js_State *J)
{
    uint8_t* res = (uint8_t*)get_glbl_var_addr("ms");
    js_pushboolean(J, res[0xa0]); // offset(CMsStateGlbls.lb)
}

void Input_mouse_rb(js_State *J)
{
    uint8_t* res = (uint8_t*)get_glbl_var_addr("ms");
    js_pushboolean(J, res[0xa1]); // offset(CMsStateGlbls.rb)
}

void Input_key_down(js_State *J)
{
    js_pushboolean(J, input_key_down(js_tonumber(J, 1)));
}

void Input_press_a_key(js_State *J)
{
    js_pushnumber(J, os_call_ext_str("PressAKey"));
}

void jsLT_initinput(js_State *J)
{
    js_pushobject(J, jsV_newobject(J, -1, J->Object_prototype));
    {
        jsB_propf(J, "Input.get_char", Input_get_char, 0);
        jsB_propf(J, "Input.get_string", Input_get_string, 1);
        jsB_propf(J, "Input.mouse_x", Input_mouse_x, 0);
        jsB_propf(J, "Input.mouse_y", Input_mouse_y, 0);
        jsB_propf(J, "Input.mouse_lb", Input_mouse_lb, 0);
        jsB_propf(J, "Input.mouse_rb", Input_mouse_rb, 0);
        jsB_propf(J, "Input.press_a_key", Input_press_a_key, 0);
        jsB_propf(J, "Input.key_down", Input_key_down, 1);
    }
    js_defglobal(J, "Input", JS_DONTENUM);
    js_dostring(J, "Input.key_up = function(sc) { return !Input.key_down(sc) }");
}

/** OS **/

// U0 Beep(I8 ona=62,Bool busy=FALSE)
void OS_beep(js_State *J)
{
    long ona = value_or_number(62, 1);
    long busy = null_or_number(2);
    os_call_ext_str_2("Beep", ona, busy);
    js_pushundefined(J);
}

// _extern _MALLOC U8 *MAlloc(I64 size,CTask *mem_task=NULL);
void OS_malloc(js_State *J)
{
    if (js_isundefined(J, 1)) {
        js_pushundefined(J);
        return;
    }
    long size = js_tonumber(J, 1);
    long mem_task = null_or_number(2);
    js_pushnumber(J, os_call_ext_str_2("MAlloc", size, mem_task));
}

// U8 *CAlloc(I64 size,CTask *mem_task=NULL)
void OS_calloc(js_State *J)
{
    if (js_isundefined(J, 1)) {
        js_pushundefined(J);
        return;
    }
    long size = js_tonumber(J, 1);
    long mem_task = null_or_number(2);
    js_pushnumber(J, os_call_ext_str_2("CAlloc", size, mem_task));
}

// _extern _FREE U0 Free(U8 *addr); //Free MAlloc()ed memory chunk.
void OS_free(js_State *J)
{
    if (!js_isundefined(J, 1)) {
        long addr = js_tonumber(J, 1);
        os_call_ext_str_1("Free", addr);
    }
    js_pushundefined(J);
}

void OS_jiffies(js_State *J)
{
    js_pushnumber(J, os_jiffies());
}

void OS_read_file_as_string(js_State *J)
{
    if (js_isundefined(J, 1)) {
        js_pushundefined(J);
        return;
    }
    const char* filename = js_tostring(J, 1);
    char* file_as_string = (char*)os_call_ext_str_3("FileRead", (uint64_t)filename, 0, 0);
    js_pushstring(J, file_as_string ? file_as_string : "");
    free(file_as_string);
}

// U0 Reboot()
void OS_reboot(js_State *J)
{
    os_call_ext_str("Reboot");
}

// U0 Sleep(I64 mS)
void OS_sleep(js_State *J)
{
    if (!js_isundefined(J, 1)) {
        long ms = js_tonumber(J, 1);
        os_call_ext_str_1("Sleep", ms);
    }
    js_pushundefined(J);
}

// U0 Snd(I8 ona=0)
void OS_snd(js_State *J)
{
    long ona = null_or_number(1);
    os_call_ext_str_1("Snd", ona);
    js_pushundefined(J);
}

void OS_write_file_as_string(js_State *J)
{
    if (js_isundefined(J, 1) || js_isundefined(J, 2)) {
        js_pushundefined(J);
        return;
    }
    const char* filename = js_tostring(J, 1);
    const char* string = js_tostring(J, 2);
    long length = strlen(string);
    js_pushnumber(J, os_call_ext_str_5("FileWrite", (uint64_t)filename, (uint64_t)string, length, 0, 0));
}

void jsLT_initos(js_State *J)
{
    js_pushobject(J, jsV_newobject(J, -1, J->Object_prototype));
    {
        jsB_propf(J, "OS.beep", OS_beep, 2);
        jsB_propf(J, "OS.malloc", OS_malloc, 2);
        jsB_propf(J, "OS.calloc", OS_calloc, 2);
        jsB_propf(J, "OS.free", OS_free, 1);
        jsB_propf(J, "OS.jiffies", OS_jiffies, 0);
        jsB_propf(J, "OS.read_file_as_string", OS_read_file_as_string, 1);
        jsB_propf(J, "OS.write_file_as_string", OS_write_file_as_string, 2);
        jsB_propf(J, "OS.reboot", OS_reboot, 0);
        jsB_propf(J, "OS.sleep", OS_sleep, 1);
        jsB_propf(J, "OS.snd", OS_snd, 1);
    }
    js_defglobal(J, "OS", JS_DONTENUM);
}

void js_initlibtemple(js_State *J)
{
    jsLT_initdc(J);
    jsLT_initgr(J);
    jsLT_initinput(J);
    jsLT_initos(J);
}
