# mujs

MuJS Javascript interpreter with TempleOS bindings

![MuJS](https://git.checksum.fail/alec/mujs/raw/branch/main/screenshot.png)
